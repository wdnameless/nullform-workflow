import type { Register } from 'claude-code'

// Страж удаления: необратимые команды Bash идут только после «Выполнить».
// rm ловится с флагом рекурсии в любом месте команды: rm -rf, rm -f -r, rm -v -R, rm --recursive.
const RULES: { re: RegExp; what: string }[] = [
  { re: /\brm\s+(?:[^;&|]*\s)?(?:-[a-zA-Z]*[rR][a-zA-Z]*|--recursive)(?=\s|$)/, what: 'удалить папку целиком' },
  { re: /\bgit\s+push\b.*(\s-f\b|--force)/, what: 'перезаписать историю на сервере (force push)' },
  { re: /\bgit\s+reset\s+--hard\b/, what: 'стереть несохранённые правки (git reset --hard)' },
  { re: /\bgit\s+clean\s+-[a-zA-Z]*f/, what: 'удалить неотслеживаемые файлы (git clean)' },
  { re: /\bfind\b.*\s-delete\b/, what: 'удалить найденные файлы (find -delete)' },
  { re: /\b(drop\s+(table|database|schema)|truncate\s+table)\b/i, what: 'удалить данные из базы' },
]

// Есть ли человек у поля ввода: в claude -p и SDK спросить некого
let isInteractive = true

// Пути после rm и его флагов — чтобы посчитать, что удалится; ~ раскрывается в домашнюю папку
function rmTargets(cmd: string, home: string | undefined): string[] {
  const m = cmd.match(/\brm\s+([^;&|]+)/)
  if (!m) return []
  return m[1]
    .trim()
    .split(/\s+/)
    .filter(p => p && !p.startsWith('-'))
    .map(p => p.replace(/^["']|["']$/g, ''))
    .map(p => (home && (p === '~' || p.startsWith('~/')) ? home + p.slice(1) : p))
    .slice(0, 10)
}

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    isInteractive = e.isInteractive
    return next(e)
  })

  on('tool.call', { tool: 'Bash' }, async ($, e, next) => {
    const rule = RULES.find(r => r.re.test(e.command))
    if (!rule) return next(e)

    // Без интерфейса (claude -p, скрипты, прогоны Autopilot без окна) — решают обычные правила
    // разрешений Claude Code, как без мода; иначе страж молча отменял бы каждое удаление.
    if (!isInteractive) return next(e)

    let scope = ''
    const home = (await $.env.get('HOME')) ?? (await $.env.get('USERPROFILE'))
    const targets = rmTargets(e.command, home)
    if (targets.length > 0) {
      try {
        const files = await $.process.run(['find', ...targets, '-type', 'f'], { timeoutMs: 5000 })
        const size = await $.process.run(['du', '-sch', ...targets], { timeoutMs: 5000 })
        const n = files.stdout.split('\n').filter(Boolean).length
        const total = size.stdout.trim().split('\n').pop()?.split(/\s+/)[0] ?? ''
        if (n > 0 || total) scope = ` — ${n} файлов, ${total}`
      } catch {
        scope = '' // на Windows без find/du — спрашиваем без подсчёта
      }
    }

    let answer = 'Отменить'
    try {
      answer = await $.ui.ask(`Claude хочет ${rule.what}${scope}:\n${e.command.slice(0, 200)}\nВыполнить?`, {
        header: 'Страж',
        options: ['Отменить', 'Выполнить'],
      })
    } catch {
      answer = 'Отменить' // вопрос закрыли — значит, нет
    }
    return answer === 'Выполнить'
      ? next(e)
      : { deny: `Страж удаления: пользователь отменил «${rule.what}». Не повторяй эту команду; предложи безопасный вариант (копия, корзина) и спроси.` }
  })
}
